
--liquibase formatted sql

--changeset marcosp:create_table

CREATE TABLE IF NOT EXISTS product (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    descricao TEXT,
    preco DECIMAL(10, 2),
    category_path VARCHAR(255),
    disponivel BOOLEAN 
);