package com.category_store.service;

import org.springframework.stereotype.Service;

import com.category_store.dto.ProductsDTO;
import com.category_store.entity.productsEntity;
import com.category_store.repository.productsRepository;

@Service
public class ProductsServiceImpl implements ProductsService {
	private productsRepository productsRepo;
   
    public void addProducts(ProductsDTO products) {
    	productsEntity novoProduto = new productsEntity();
    	novoProduto.setName(products.getName());
    	novoProduto.setDescription(products.getDescription());
    	novoProduto.setPrice(products.getPrice()); 
    	novoProduto.setCategoryPath(products.getCategoryPath());
    	novoProduto.setResponsible(products.getResponsible());

    	// save the new product
    	productsEntity saveProducts = productsRepo.save(novoProduto);
    }
    
    @Override
    public void changeProducts(ProductsDTO productsDTO) {
        // find the product in repo
        productsEntity existingProduct = productsRepo.findById(productsDTO.getId())
                                                     .orElseThrow(() -> new IllegalArgumentException("not found"));

        // update fields
        existingProduct.setName(productsDTO.getName());
        existingProduct.setDescription(productsDTO.getDescription());
        existingProduct.setPrice(productsDTO.getPrice());
        existingProduct.setCategoryPath(productsDTO.getCategoryPath());
        existingProduct.setResponsible(productsDTO.getResponsible());

        // save the product
        productsRepo.save(existingProduct);
    }
    
    @Override
    public void deleteProduct(Long productId) {
        // verify if product exist
        if (productsRepo.existsById(productId)) {
            // delete him
            productsRepo.deleteById(productId);
        } else {
            throw new IllegalArgumentException("Produto não encontrado para exclusão");
        }
    }
}
