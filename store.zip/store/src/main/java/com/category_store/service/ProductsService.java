package com.category_store.service;

import com.category_store.dto.ProductsDTO;

public interface ProductsService {

	void addProducts(ProductsDTO productsDTO);
	
	void changeProducts(ProductsDTO productsDTO);

	void deleteProduct(Long productId);

}
