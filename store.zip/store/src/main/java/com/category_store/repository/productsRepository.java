package com.category_store.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.category_store.entity.productsEntity;

@Repository
public interface productsRepository extends JpaRepository<productsEntity, Long> {
	 
	 void delete(productsEntity product);
		
	 void change(productsEntity product);
}
