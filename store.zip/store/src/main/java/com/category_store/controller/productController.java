package com.category_store.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.category_store.dto.ProductsDTO;
import com.category_store.service.ProductsService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;




@RestController
@RequestMapping("/")
public class productController {
    private ProductsService productService = null;
    
    @Autowired
    public void ProductController(ProductsService productService) {
        this.productService = productService;
    }
    
    @PostMapping("/saveProducts")
    public String addProducts(@RequestBody ProductsDTO productsDTO) {
        productService.addProducts(productsDTO);
        return "Products added successfully!";
    }
    
    @PostMapping("/changeProducts")
    public String changeProductsProducts(@RequestBody ProductsDTO productsDTO) {
        productService.addProducts(productsDTO);
        return "Products added successfully!";
    }
    
    @PostMapping("/deleteProducts/{id}")
    public String deleteProductsProducts(@PathVariable Long id) {
        productService.deleteProduct(id);
        return "Products delete successfully!";
    }
    
    @GetMapping("/testing")
    public String hello() {
        return "Olá, Mundo!";
    }
}