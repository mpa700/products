package com.category_store.dto;


public class ProductsDTO {
    public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getCategoryPath() {
		return CategoryPath;
	}
	public void setCategoryPath(String categoryPath) {
		CategoryPath = categoryPath;
	}
	public String getResponsible() {
		return responsible;
	}
	public void setResponsible(String responsible) {
		this.responsible = responsible;
	}
	public Long getId() {
		return id;
	}
	private String name;
    private String description;
    private Double price;
    private String CategoryPath;
    private String responsible;
    private Long id;
	
        
}